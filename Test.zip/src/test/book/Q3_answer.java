package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q3_answer {
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q3_answer() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이브 로드 성공");
			
			con = DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
//	main 메소드에서 runSQL(1,"스포츠") 호출, 1은 [검색메뉴] 값을 의미, 스포츠는 [검색어]를 의미
//	searchMenu가 1이면 도서검색, 2면 고객명검색
	public void runSQL(int searchMenu, String SearchWord) {
		String sql = "";
		
		switch (searchMenu) {
			case 1:
				sql = "SELECT name, b.bookname, saleprice FROM customer c, book b, orders o "
						+ "WHERE o.custid = c.custid AND o.bookid = b.bookid "
						+ "AND b.bookname LIKE '%" + SearchWord + "%' ORDER BY name";
				break;
			
			case 2:
				sql = "SELECT name, b.bookname, saleprice FROM customer c, book b, orders o "
						+ "WHERE o.custid = c.custid AND o.bookid = b.bookid "
						+ "AND name LIKE '%" + SearchWord + "%' ORDER BY name";
				break;
		}
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.print("\t"+rs.getString("name"));
				System.out.print("\t"+rs.getString("bookname"));
				System.out.println("\t\t"+rs.getInt("saleprice"));
			}
			
			con.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
//		주문정보 중에서 고객명, 도서명, 판매가격을 도서명 또는 고객명으로 주문 정보를 검색하여 콘솔 창에 고객명(오름차순)으로 출력하시오
//		콘솔창에서 도서명 또는 고객명의 일부를 입력받아 검색이 되게 합니다.
//		[검색메뉴]
//		1.도서명
//		2.고객명
		Scanner s1 = new Scanner(System.in);
		Scanner s2 = new Scanner(System.in);
		Q3_answer bList = new Q3_answer();
		
		System.out.println("[검색메뉴]");
		System.out.println("1.도서명");
		System.out.println("2.고객명");
		
		System.out.print("* 검색메뉴를 선택하세요.(1 또는 2를 입력): ");
		int searchMenu = s1.nextInt();
		String searchWord;
		
		switch(searchMenu) {
		case 1:
			System.out.print("* 도서명의 검색어를 입력: ");
			break;
			
		case 2:
			System.out.print("* 고객명의 검색어를 입력: ");
			break;
		}
		
		searchWord = s2.nextLine();
			
		s1.close();
		s2.close();
		
		bList.runSQL(searchMenu, searchWord);
	}
}
