package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q2 {
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q2() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이브 로드 성공");
			
			con = DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void runSQL(String name) {
//		SQL 명령 입력
		String sql = "SELECT bookid, bookname, price FROM book WHERE bookname Like '%" +name+ "%' ORDER BY bookid";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.print("\t"+rs.getInt("bookid"));
				System.out.print("\t"+rs.getString("bookname"));
				System.out.println("\t\t"+rs.getString("price"));
			}
			
			con.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
//		도서명으로 검색하여 도서번호, 도서명, 가격을 콘솔 창에 도서번호 순(오름차순)으로 출력하시오
//		콘손창에서 도서명의 일부를 입력받아 검색이 되게 합니다
		Scanner scan = new Scanner(System.in);
		Q2 bList = new Q2();		
		
		System.out.print("도서 검색: ");
		String search = scan.next();
		bList.runSQL(search);
		scan.close();
	}
}
