package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q3 {
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q3() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이브 로드 성공");
			
			con = DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void runSQL1(String name) {
//		SQL 명령 입력
		String sql = "SELECT name, book.bookname, saleprice FROM customer, book, orders WHERE orders.custid = customer.custid AND orders.bookid = book.bookid AND book.bookname Like '%" +name+ "%' ORDER BY name";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.print("\t"+rs.getString("name"));
				System.out.print("\t"+rs.getString("bookname"));
				System.out.println("\t\t"+rs.getInt("saleprice"));
			}
			
			con.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void runSQL2(String name) {
//		SQL 명령 입력
		String sql = "SELECT name, b.bookname, saleprice FROM customer c, book b, orders o WHERE o.custid = c.custid AND o.bookid = b.bookid AND name Like '%" +name+ "%' ORDER BY name";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.print("\t"+rs.getString("name"));
				System.out.print("\t"+rs.getString("bookname"));
				System.out.println("\t\t"+rs.getInt("saleprice"));
			}
			
			con.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
//		주문정보 중에서 고객명, 도서명, 판매가격을 도서명 또는 고객명으로 주문 정보를 검색하여 콘솔 창에 고객명(오름차순)으로 출력하시오
//		콘솔창에서 도서명 또는 고객명의 일부를 입력받아 검색이 되게 합니다.
//		[검색메뉴]
//		1.도서명
//		2.고객명
		Scanner scan = new Scanner(System.in);
		Q3 bList = new Q3();
		
		System.out.println("[검색메뉴]");
		System.out.println("1.도서명");
		System.out.println("2.고객명");
		
		System.out.print("검색메뉴를 선택하세요.(1 또는 2를 입력): ");
		int choice = scan.nextInt();
			
		switch(choice) {
			case 1:
				System.out.print("도서명의 검색어를 입력: ");
				String bName = scan.next();
				bList.runSQL1(bName);
				scan.close();
				break;
				
			case 2:
				System.out.print("고객명의 검색어를 입력: ");
				String name = scan.next();
				bList.runSQL2(name);
				scan.close();
				break;
				
			default:
				System.out.println("다시 입력하시오.");
		}		
	}
}
