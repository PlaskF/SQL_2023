package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q4 {
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q4() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이브 로드 성공");
			
			con = DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void runSQL(int searchMenu, String SearchWord) {
		String sql = "";
		System.out.printf("%-10s", "고객명");
		System.out.printf("%-20s", "도서명");
		System.out.printf("\t%s\n", "판매가격");
		System.out.println("=======================================================");
		
		switch (searchMenu) {
			case 1:
				sql = "SELECT name, b.bookname, saleprice FROM customer c, book b, orders o "
						+ "WHERE o.custid = c.custid AND o.bookid = b.bookid "
						+ "AND b.bookname LIKE '%" + SearchWord + "%' ORDER BY name";
				break;
			
			case 2:
				sql = "SELECT name, b.bookname, saleprice FROM customer c, book b, orders o "
						+ "WHERE o.custid = c.custid AND o.bookid = b.bookid "
						+ "AND name LIKE '%" + SearchWord + "%' ORDER BY name";
				break;
		}
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.printf("%-10s",rs.getString("name"));
				System.out.printf("%-20s",rs.getString("bookname"));
				System.out.printf("\t%-10d\n",rs.getInt("saleprice"));
			}
			
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Scanner s1 = new Scanner(System.in);
		Scanner s2 = new Scanner(System.in);
		Q4 bList = new Q4();
		
		while (true) {
			System.out.println("[검색메뉴]");
			System.out.println("1.도서명");
			System.out.println("2.고객명");
			System.out.println("3.종료");
			
			System.out.print("* 검색메뉴를 선택하세요.(1,2,3 중 하나 입력): ");
			int searchMenu = s1.nextInt();
			String searchWord;
			
			switch(searchMenu) {
				case 1:
					System.out.print("* 도서명의 검색어를 입력: ");
					searchWord = s2.nextLine();
					bList.runSQL(searchMenu, searchWord);
					break;
					
				case 2:
					System.out.print("* 고객명의 검색어를 입력: ");
					searchWord = s2.nextLine();
					bList.runSQL(searchMenu, searchWord);
					break;
					
				case 3:
					System.out.print("* 프로그램을 종료합니다.");
					s1.close();
					s2.close();
					try {
						bList.con.close();
					} 
					catch (SQLException e) {
						e.printStackTrace();
					}
					System.exit(0);
			}
		}
	}
}
